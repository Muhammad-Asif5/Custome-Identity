export const environment = {
  production: true,
  apiUrl: 'https://localhost:44352/api'
};
