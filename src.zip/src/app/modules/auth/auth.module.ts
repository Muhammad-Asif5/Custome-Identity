import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthComponent } from './auth.component';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ForgetPasswordComponent } from './ForgetPassword/forget-password.component';
import { LoginComponent } from './Login/login.component'; 

// const routes: Routes = [
//   { path: '', component: MainboardComponent,children:[
//     { path: 'dashboard', component: DashboardComponent},  
//     { path: 'all-customer', component: CustomerComponent},
//     { path: 'all-airline', component: APComponent},
//     { path: 'all-expenses', component: EXPComponent},
//     { path: 'all-agent', component: AgentComponent},
//     { path: 'all-income', component: StreamComponent},
//     { path: 'all-Bank', component: BankComponent},
//     { path: '', redirectTo: '/dashboard' ,pathMatch:'full' } ,

//   ]},

const routes: Routes = [
  { path: '', component: AuthComponent , children:[
     { path: '', redirectTo: '/login' ,pathMatch:'full' },
     { path: 'login', component: LoginComponent },
     { path: 'ForgetPassword', component: ForgetPasswordComponent },  
  ]},
 
]

@NgModule({
  declarations: [
    AuthComponent,
    LoginComponent,
    ForgetPasswordComponent,    
  ],
  imports: [ 
    CommonModule,
    RouterModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    AuthComponent,
    RouterModule
  ]
})
export class AuthModule { }
