import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { AccountService } from 'src/app/core';
import { AuthResponse } from 'src/app/core/models'; 


@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.sass']
})
export class ForgetPasswordComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, 
    private route: ActivatedRoute, 
    private router: Router, 
    private accountService: AccountService) {
    debugger
     if (this.accountService.GetUser().isAuthenticated) {
       this.router.navigate(["dashboard"]);
     }
    
  }

  userName: string;

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  ngOnInit(): void {

    this.loginForm = this.formBuilder.group({
      Username: ['', Validators.required],
      Email: ['', Validators.required],
      Password: ['', Validators.required]
    });

    this.userName = "athar.ahmad";
  }
  get f() { return this.loginForm.controls; }

  //#region Login

  onSubmit() {
    this.submitted = true;

    // reset alerts on submit

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    
    this.loading = true;
    this.accountService.login(this.loginForm.value)
      .pipe(first())
      .subscribe((data: AuthResponse) => {
        debugger
        //this.utilityService.Redirect(URLS.auth.login);
        //localStorage.setItem("token", data.token);
        //this.accountService.userInitialization();

        //// get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
        this.ResetLoginPage();
        if (this.returnUrl != '/') {
          this.router.navigate([this.returnUrl]);
        }
        else {
          //this.utilityService.Redirect(URLS.mainboard.dashboard);
          //this.router.navigate(['dashboard']);
        }
      },
        error => {
          debugger
          alert(error.status + ' ' + error.error);
          this.ResetLoginPage();
        });
  }

//#endregion

 
  ResetLoginPage() {
    this.loading = false;
    this.loginForm.reset();
    Object.keys(this.loginForm.controls).forEach(key => {
      //this.loginForm.get(key).setErrors(null);
    })
  }


}
