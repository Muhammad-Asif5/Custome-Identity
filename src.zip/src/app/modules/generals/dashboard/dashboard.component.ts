import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import * as $ from 'jquery';
import * as Highcharts from 'highcharts/highstock';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.sass']
})
export class DashboardComponent implements OnInit {


  @ViewChild('donut') donut: ElementRef;
  constructor() { }
  Highcharts: typeof Highcharts = Highcharts;

  chartConstructor: string = 'chart';
  chartOptions: Highcharts.Options = {
    credits: {
      enabled: false
    },
    series: [{
      name: 'series Name',
      data: [
        {
          y: 21, color: '#4747a7', name: 'opq',
          drilldown: 'MSIE versions'
        },
        { y: 21, color: '#dc3545', name: 'abc' },
        { y: 22, color: '#28a745', name: 'lmn' },
        { y: 23, color: '#ffc107', name: 'xyz' }
      ],
      //data: [["Firefox",6],["MSIE",4],["Chrome",7]],
      type: 'pie',
      innerSize: '50%',
      size: '100%',
    }]
  };
  chartOptions1: Highcharts.Options = {
    credits: {
      enabled: false
    },
    chart: {
      type: 'column'
    },
    title: {
      text: 'Monthly Average Rainfall'
    },
    subtitle: {
      text: 'Source: WorldClimate.com'
    },
    xAxis: {
      categories: [
        'Jan',
        'Feb',
        'Mar'
      ],
      crosshair: true
    },
    yAxis: {
      min: 0,
      title: {
        text: 'Rainfall (mm)'
      }
    },
    tooltip: {
      headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
      pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
        '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
      footerFormat: '</table>',
      shared: true,
      useHTML: true
    },
    plotOptions: {
      column: {
        pointPadding: 0.2,
        borderWidth: 0
      }
    },
    series: [
      {
        name: 'Tokyo',
        data: [
          { y: 21,  name: 'abc' },
          { y: 22, name: 'lmn' },
          { y: 23,  name: 'xyz' }
        ],
        type: 'column',
        color: '#4747a7'
      },
      {
        name: 'Tokyo 2',
        data: [
          { y: 31,  name: 'absc'},
          { y: 32,  name: 'lmn' },
          { y: 33, name: 'xyz' }
        ],
        type: 'column',
        color: '#dc3545'        
      }
    ]
  };

  ngOnInit(): void {

  }


}
