import { HttpResponse } from '@angular/common/http';
import { Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first, of } from 'rxjs';
import { Bank, BankService, ExcelService } from 'src/app/core';
import { compare, SortableHeaderDirective, SortEvent } from 'src/app/core/directives/sortable-header.directive';
import { GeneralsModalPopUpService } from 'src/app/shared';
import swal from 'sweetalert2';


@Component({
  selector: 'app-stream',
  templateUrl: './stream.component.html',
  styleUrls: ['./stream.component.sass']
})
export class StreamComponent implements OnInit {

  @ViewChild('myForm') myForm: NgForm;
  isAddMode: boolean;
  id: string;
  modalId: string;
  bankModels: Bank = {
    bank_ID: 0,
    bank_Name: '',
    status: 'A',
    isDeleting: '',
    isEditing: ''
  }

  constructor(private router: Router, private excelService: ExcelService, private _modalService: GeneralsModalPopUpService, public bankService: BankService, private formBuilder: FormBuilder) {
    this.header = ['Year', 'Month', 'Make'];
  }
  returnUrl: string;
  ngOnInit(): void {


    this.users = null;
    this.modalId = '';
    this.isAddMode = true;
    this.bankModels;
    this.bankService.myClassBinding = 'btn btn-success';
    this.bankService.RegisterBtn = 'Register';
    this.getAllBankList();
    this.bankForm = this.formBuilder.group(
      {
        Bank_ID: [0],
        Bank_Name: ['', Validators.required],
        Status: ['null' || '' || null, Validators.required]
      }
    );
    this.bankModel = {
      bank_ID: 0,
      bank_Name: '',
      status: 'A',
      isDeleting: '',
      isEditing: ''
    }
  }
  title: string = 'Car Sell Report For Test';
  header: string[];
  //data: any[];
  
  //countries: Array<Bank> = dataset;

  generateExcel(sheetName: string, fileName: string) {
    this.bankService.ExportExcel(fileName);
    //this.excelService.GenerateExcel(this.header, this.data, this.title, sheetName, fileName);
  }

  openModal(id: string) {
    this.modalId = id;
    this._modalService.width = 50;
    this._modalService.open(id);
    this.onReset();
  }
  closeModal(id: string) {
    this._modalService.close(id);
  }


  //#region Get All Data
  users: any;
  items: any = [];
  pageSize: number;
  listOfBank: Bank[] = [];

  total: number = 0;
  p: number = 1;
  pageChangeEvent(event: number) {
    this.p = event;
    this.getAllBankList();
  }

  data: Array<Bank> = [];
  countries: Array<Bank> = [];

  getAllBankList() {

    this.bankService.GetAllBank().subscribe((data: any[]) => {

      // $('#datatableexample').DataTable( {
      //   pagingType: 'full_numbers',
      //   pageLength: 5,
      //   processing: true,
      //   lengthMenu : [5, 10, 25]
      // });

      // this.tableData = data;
      // this.dtOptions = {
      //   data: this.tableData,
      //   columns: [
      //     {title: 'ID', data: 'id'},
      //     {title: 'Email', data: 'email'},
      //     {title: 'First Name', data: 'first_name'},
      //     {title: 'Last Name', data: 'last_name'},
      //     {title: 'Avatar', data: 'avatar'},
      //   ]
      // };

      this.countries = data;
      this.data = data;
      // this.items = Array(data.length).fill(0).map((x, i) => (
      //   //{ id: (i + 1), name: `Item ${i + 1}` }
      //   {
      //     Bank_ID: (data[i].bank_ID),
      //     Bank_Name: (data[i].bank_Name),
      //     Status: (data[i].status),
      //     isDeleting: '',
      //     isEditing: ''
      //     //,Status: data[i].status? 'Active': 'Closed'
      //   }
      // ));

      return of(new HttpResponse({ status: 200, body: this.items }));
    }, error => {

      alert(error.Code + ', ' + error.Message + ', ' + error.Description);

      //this.router.navigate(['account/login']); 
    })
  }
  pageOfItems: Array<Bank>;

  onChangePage(pageOfItems: Array<Bank>) {
    this.pageOfItems = pageOfItems;
  }

  //#endregion

  //#region filtered Bank Data
  filteredBank: Bank[];
  private _searchTerm: string;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(value: string) {
    this._searchTerm = value;
    this.filteredBank = this.filtereBank(value);
  }
  filtereBank(searchString: string) {
    return this.pageOfItems.filter(bank =>
      bank.bank_Name.toLowerCase().indexOf(searchString.toLowerCase()) !== -1)
  }

  //#endregion

  //#region Submit Bank Data

  bankModel: Bank;
  MaxID: number;
  bankForm: FormGroup;
  submitted = false;
  get f() { return this.bankForm.controls; }

  onSubmit(modalID: string): void {

    if (this.bankForm.controls['Status'].value == 'null') {
      this.f['Status'].setValue(null);
    }
    // else{
    //   const SET_STATUS_VALUE = this.bankForm.controls.Status.value=='A' ? true : false;
    //   this.f.Status.setValue(SET_STATUS_VALUE);
    // }
    this.submitted = true;

    if (this.bankForm.invalid) {
      return;
    }


    if (this.isAddMode == true) {
      this.createUser();
    } else {
      this.updateUser();
    }

  }

  createUser() {

    this.bankService.RegisterBank(this.bankForm.value)
      .pipe(first())
      .subscribe(
        data => {
          swal.fire('SUCCESS!', 'Update Successfully!', 'success');
          this._modalService.close(this.modalId);
          this.getAllBankList();
        },
        error => {
          swal.fire({
            icon: 'error', title: 'Oops...',
            text: error
          })
        });
  }

  updateUser() {

    this.bankService.update(this.id, this.bankForm.value)
      .pipe(first())
      .subscribe(
        data => {
          swal.fire('SUCCESS!', 'Update Successfully!', 'success');
          this._modalService.close(this.modalId);
          this.getAllBankList();
        },
        error => {
          swal.fire({
            icon: 'error', title: 'Oops...',
            text: error
          })
        });
  }

  //#endregion



  //#region Reset Data
  onReset(): void {
    this.isAddMode = true;
    this.submitted = false;
    this.bankForm.reset();
    //this.myForm.reset();
    this.f['Bank_ID'].setValue(0);
    this.bankService.myClassBinding = 'btn btn-success';
    this.bankService.RegisterBtn = 'Register';
  }
  //#endregion

  //#region Edit Bank Data
  editData(item: Bank, modalID: string) {
    this.modalId = modalID;
    const user = this.items.find((x: any) => x.Bank_ID === item.bank_ID);
    //user.isEditing = true;
    this.id = user.Bank_ID;
    this.isAddMode = false;
    this.bankService.getById(item.bank_ID.toString())
      .pipe(first())
      .subscribe((x: any) => {
        this.f['Bank_ID'].setValue(x.bank_ID);
        this.f['Bank_Name'].setValue(x.bank_Name);
        this.f['Status'].setValue(x.status ? 'A' : 'C');

        this._modalService.width = 50;
        this.bankService.RegisterBtn = 'Update';
        this.bankService.myClassBinding = 'btn btn-primary';

        this._modalService.open('custom-modal-1');
        //user.isEditing = false;
      },
        error => {
          // this.loading = false;
          swal.fire({
            icon: 'error', title: 'Oops...',
            text: error.Code + ' ' + error.Message
          })
        });


  }
  //#endregion


  //#region Delete Bank Data

  deleteBank(model: Bank) {
    const user = this.items.find((x: any) => x.Bank_ID === model.bank_ID);
    //user.isDeleting = true;

    swal.fire({
      title: 'Are you sure want to remove?',
      text: 'You will not be able to recover this file!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.bankService.delete(model.bank_ID.toString())
          .pipe(first())
          .subscribe((x: any) => {
            swal.fire('DELETED!', 'Deleted Successfully!', 'success');
            this.getAllBankList();
          },
            error => {
              // this.loading = false;
              swal.fire({
                icon: 'error', title: 'Oops...',
                text: error
              })
            });
        // .subscribe((res: any) => {
        //   if (res == true) {
        //     this.items = this.items.filter(item => item.Bank_ID !== model.Bank_ID);
        //     Swal.fire('DELETED!', 'Deleted Successfully!', 'success');
        //   } else {
        //     Swal.fire({
        //       icon: 'error', title: 'Oops...',
        //       text: 'Something went wrong!'
        //     })
        //   }
        // })
      } else if (result.dismiss === swal.DismissReason.cancel) {
        //user.isDeleting = false;
        //Swal.fire('Cancelled', 'Your imaginary file is safe :)', 'error')  
      }
    })


  }
  //#endregion



  /// Search by click
  changeBankName() {
    //this.pageOfItems[0].Bank_Name = 'Asif';
    //const asif: Bank = { Bank_ID: 10, Bank_Name: 'asif', Status: '' };
    //const newBankArray :Bank[] = Object.assign([], this.pageOfItems);
    const newBankArray: Bank[] = Object.assign([], this.pageOfItems);
    //newBankArray.push(asif);
    this.pageOfItems = newBankArray;
  }

  sortOrder = 1;
  sortProperty: string = 'bank_ID';

  sortIcon(property: string) {
    if (property === this.sortProperty) {
      return this.sortOrder === 1 ? '☝️' : '👇';
    }
    return '';
  } 

  filter: string;
  sortable:string='';
  @ViewChildren(SortableHeaderDirective)
  headers: QueryList<SortableHeaderDirective>;

  onSort({ column, direction }: SortEvent) {
    debugger
    // resetting other headers
    this.headers.forEach((header) => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });

    // sorting countries
    if (direction === '' || column === '') {
      this.countries = this.data;
    } else {
      this.countries = [...this.data].sort((a, b) => {
        const res = compare(a[column], b[column]);
        return direction === 'asc' ? res : -res;
      });
    }
  }



}
