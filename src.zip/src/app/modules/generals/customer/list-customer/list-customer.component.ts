import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { Customer, CustomerService } from 'src/app/core';
import { ColDef, GetRowIdFunc, GetRowIdParams, GridApi, GridReadyEvent, SelectionChangedEvent } from 'ag-grid-community';
import 'ag-grid-enterprise';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.sass']
})
export class ListCustomerComponent implements OnInit {
  @Output() newItemEvent = new EventEmitter<Customer>();
 // @ViewChild('agGrid') agGrid: AgGridAngular;
 @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  //rowData: Observable<any[]>; 

  constructor(private _service: CustomerService) {}
  bodyText: string;
  customerList: Customer[];
  customerListAll: Customer[];
  total: number;
  rowDataB: Customer[];

  ngOnInit(): void { 
    this._service.GetCustomer().subscribe((data:  Customer[]) => {
      this.customerListAll = data;
      this.customerList = this.customerListAll.slice(0,50).sort();
    });

  }

  defaultColDef : ColDef = {
    flex: 1,
    minWidth: 100,
    sortable: true,
    filter: true,
    editable: true
  };

  autoGroupColumnDef = {
    headerName: 'cty',
    field: 'city',
    cellRenderer: 'agGroupCellRenderer',
    cellRendererParams: {
      checkbox: true
    }
  };


  columnDefs: ColDef[] = [
    { field: 'cust_ID', sortable: false, filter: false, checkboxSelection: true },
    { field: 'lookup' },
    { field: 'cust_Code' },
    { field: 'contact_Name' },
    { field: 'address' },
    { field: 'city' },
    // { field: 'City', rowGroup: true },
    { field: 'state' },
    { field: 'zIP_Code' },
    { field: 'phone' },
    { field: 'email' },
    { field: 'fax' }
  ];


  onSelectionChanged(event: SelectionChangedEvent) { 
    const selectedData = this.agGrid.api.getSelectedRows();
    this.newItemEvent.emit(selectedData[0]);

    this._service.subject.subscribe((data) => {
      debugger
      const selectedRowNodes = this.agGrid.api.getSelectedNodes();
      const selectedIds = selectedRowNodes.map(function (rowNode) {
        return rowNode.id;
      });
      this.customerListAll = this.customerListAll.filter(function (dataItem) {
        return selectedIds.indexOf(dataItem.cust_Code) < 0;
      });
       
      this.agGrid.api.setRowData(this.customerListAll);


      // var updatedData = {cust_ID:1,lookup:'abc',cust_Code:'abc',
      // company_Name:'abc',contact_Name:'abc',
      // address:'abc',city:'abc',state:'abc',zIP_Code:'abc',phone:'abc',email:'abc',fax:'abc'};
      
      //this.customerListAll.push(updatedData)
      //this.agGrid.api.setRowData(this.customerListAll);

      // Whenever the parent emits using the next method,
      // you can receive the data in here and act on it.
  });
    console.log('Selection updated');
  }
  onCellClicked(id:any) { 
    alert(id.data.cust_ID);
  }
 
  onPageSizeChanged(event:any) { 
    this.customerList = [];
    const end = event.target.value;
    this.customerList = this.customerListAll.slice(0,end).sort();
  }
  

  onChangePage(customerList: Array<Customer>) {
    // update current page of items
    this.customerList = customerList;
  }



}
