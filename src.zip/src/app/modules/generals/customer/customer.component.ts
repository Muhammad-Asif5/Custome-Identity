import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs';
import { Customer, BankService, ExcelService, CustomerService } from 'src/app/core';
import { GeneralsModalPopUpService } from 'src/app/shared';
import swal from 'sweetalert2';
declare const $: any;

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.sass']
})
export class CustomerComponent implements OnInit {
  customerForm: FormGroup;
  modalId: string;
  customerModels: Customer = {
    cust_ID: 0,
    lookup: '',
    cust_Code: '',
    company_Name: '',
    contact_Name: '',
    address: '',
    city: '',
    state: '',
    zIP_Code: '',
    phone: '',
    email: '',
    fax: ''
  }
  get f() { return this.customerForm.controls; }

  constructor(private _modalService: GeneralsModalPopUpService, public customerService: CustomerService, private formBuilder: FormBuilder) { }
  mode: string = 'Add New Customer';
  headerColor: string = 'bg-success';
  bankModel: Customer;
  ngOnInit(): void {

    this.modalId = '';
    this.isAddMode = true;
    this.customerModels;
    this.customerService.myClassBinding = 'btn btn-success';
    this.customerService.RegisterBtn = 'Register';

    this.customerForm = this.formBuilder.group(
      {
        Bank_ID: [0],
        Cust_Code: ['', Validators.required],
        Company_Name: ['', Validators.required],
        Contact_Name: ['', Validators.required],
        Lookup: ['', Validators.required],
        Address: [''],
        City: [''],
        State: [''],
        ZIP_Code: [''],
        Phone: [''],
        Email: [''],
        Fax: [''],
        // Status: ['null' || '' || null, Validators.required]
      }
    );
    this.bankModel = {
      cust_ID: 0,
      lookup: '',
      cust_Code: '',
      company_Name: '',
      contact_Name: '',
      address: '',
      city: '',
      state: '',
      zIP_Code: '',
      phone: '',
      email: '',
      fax: ''
    }

  }

  myClassBinding: string;
  isAddMode: boolean;
  submitted = false;
  onSubmit(modalID: string): void {
    // if (this.customerForm.controls['Status'].value == 'null') {
    //   this.f['Status'].setValue(null);
    // }
    // else{
    //   const SET_STATUS_VALUE = this.bankForm.controls.Status.value=='A' ? true : false;
    //   this.f.Status.setValue(SET_STATUS_VALUE);
    // }
    this.submitted = true;

    if (this.customerForm.invalid) {
      return;
    }


    if (this.isAddMode == true) {
      this.createUser();
    } else {
      this.updateUser();
    }

  }


  currentItem: string = 'Television';
  createUser() {

    this.customerService.AddBank(this.customerForm.value)
      .pipe(first())
      .subscribe(
        data => {
          swal.fire('SUCCESS!', 'Update Successfully!', 'success');
          this._modalService.close(this.modalId);
          //this.getAllBankList();
        },
        error => {
          swal.fire({
            icon: 'error', title: 'Oops...',
            text: error
          })
        });
  }

  updateUser() {

    this.customerService.update(this.id, this.customerForm.value)
      .pipe(first())
      .subscribe(
        data => {
          swal.fire('SUCCESS!', 'Update Successfully!', 'success');
          this._modalService.close(this.modalId);
          //this.getAllBankList();
          this.currentItem = this.id;
          this.customerService.subject.next(this.customerForm.value);
        },
        error => {
          swal.fire({
            icon: 'error', title: 'Oops...',
            text: error
          })
        });
  }

  id: string;
  items: any = [];

  //#region Edit Bank Data
  editData(user: Customer, modalID: string) {
    debugger
    this.mode = 'Update Employee';
    this.headerColor = 'bg-primary'
    this.modalId = modalID;

    this.id = user.cust_ID.toString();
    this.isAddMode = false;
    this.customerService.getById(user.cust_ID.toString())
      .pipe(first())
      .subscribe((x: any) => {
        debugger
        this.customerModels = Object.assign({}, x);
        this._modalService.width = 80;
        this.customerService.RegisterBtn = 'Update';
        this.customerService.myClassBinding = 'btn btn-primary';
        this._modalService.open(this.modalId);
      },
        error => {
          swal.fire({
            icon: 'error', title: 'Oops...',
            text: error.Code + ' ' + error.Message
          })
        });


  }
  //#endregion


  //#region Reset Data
  onReset(): void {
    this.isAddMode = true;
    this.submitted = false;
    this.customerForm.reset();
    //this.myForm.reset();
    this.f['Bank_ID'].setValue(0);
    this.customerService.myClassBinding = 'btn btn-success';
    this.customerService.RegisterBtn = 'Register';
    this.headerColor = 'bg-success';
  }
  //#endregion

  openModal(id: string) {
    this.modalId = id;
    this._modalService.width = 80;
    this._modalService.open(id);
    this.onReset();
  }
  closeModal(id: string) {
    this._modalService.close(id);
  }

}
