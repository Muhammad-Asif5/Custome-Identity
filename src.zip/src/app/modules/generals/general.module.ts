import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { GeneralComponent } from './general.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AgentComponent } from './agent/agent.component';
import { APComponent } from './ap/ap.component';
import { BankComponent } from './bank/bank.component';
import { CustomerComponent } from './customer/customer.component';
import { ExpComponent } from './exp/exp.component';
import { StreamComponent } from './stream/stream.component';
import { SideBarComponent } from 'src/app/shared/SideBar/side-bar.component';
import { NavBarComponent } from 'src/app/shared/NavBar/nav-bar.component';
import { ListCustomerComponent } from './customer/list-customer/list-customer.component';
import { AgGridModule } from 'ag-grid-angular';
import { GeneralModalPopupComponent, JwPaginationComponent } from 'src/app/shared';
import { NgxPaginationModule } from 'ngx-pagination';
import { HighchartsChartModule } from 'highcharts-angular';
import { AuthGuard } from 'src/app/core';
import { SortableHeaderDirective } from 'src/app/core/directives/sortable-header.directive';
import { BankPipe } from 'src/app/core/pipes/bank.pipe';

const routes: Routes = [
  {
    path: '', component: GeneralComponent, children: [
      { path: 'dashboard', component: DashboardComponent, canActivate:[AuthGuard] },
      { path: 'all-customer', component: CustomerComponent },
      { path: 'all-airline', component: APComponent },
      { path: 'all-expenses', component: ExpComponent },
      { path: 'all-agent', component: AgentComponent },
      { path: 'all-income', component: StreamComponent },
      { path: 'all-Bank', component: BankComponent },
      { path: '', redirectTo: '/dashboard', pathMatch: 'full' },

    ]
  }

]


@NgModule({
  declarations: [
    GeneralComponent,
    DashboardComponent,
    AgentComponent,
    APComponent,
    BankComponent,
    CustomerComponent,
    ExpComponent,
    StreamComponent,

    SideBarComponent,
    NavBarComponent,
    ListCustomerComponent,
    GeneralModalPopupComponent,
    JwPaginationComponent,
    SortableHeaderDirective,
    BankPipe
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    RouterModule.forChild(routes),
    //JwPaginationModule,
    // FormsModule,
    // CommonModule,
    ReactiveFormsModule,
    // GeneralRoutingModule,
    AgGridModule,
    NgxPaginationModule,
    HighchartsChartModule,

  ],
  exports: [
    RouterModule
  ],
  providers: [DatePipe],
})
export class GeneralModule { }
