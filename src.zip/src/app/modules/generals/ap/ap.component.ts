import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ap',
  templateUrl: './ap.component.html',
  styleUrls: ['./ap.component.sass']
})
export class APComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
