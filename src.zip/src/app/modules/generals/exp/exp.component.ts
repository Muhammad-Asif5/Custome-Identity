import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exp',
  templateUrl: './exp.component.html',
  styleUrls: ['./exp.component.sass']
})
export class ExpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
