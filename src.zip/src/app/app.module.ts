import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component'; 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { AuthModule } from './modules/auth/auth.module';
import { JwtHelperService, JWT_OPTIONS } from '@auth0/angular-jwt';
import { GeneralModule } from './modules/generals/general.module';
import { NotFoundComponent } from './not-found/not-found.component';
import { AuthGuard, AuthInterceptor } from './core';

@NgModule({
  declarations: [AppComponent,NotFoundComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    //BrowserAnimationModule,
    //AuthModule,
    //LayoutModule,
    //MainBoardModule,   
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    HttpClientModule,
    
    AuthModule,
    GeneralModule,
    
  ],
  providers: [
    AuthGuard,
    //DatePipe,
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    //{ provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    //{ provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    {provide:JWT_OPTIONS,useValue:JWT_OPTIONS}, JwtHelperService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
