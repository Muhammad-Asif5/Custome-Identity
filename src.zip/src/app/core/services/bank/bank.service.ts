import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment'; 
import { Bank } from '../..';
import { GeneralsModalPopUpService } from 'src/app/shared';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  private baseUrl = `${environment.apiUrl}/Bank`;
  formData: Bank = new Bank();
  constructor(private http: HttpClient, public _modalService: GeneralsModalPopUpService) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  RegisterBtn: string;
  myClassBinding: string;

  getBankById(id: number): Observable<Bank> {
    return this.http.get<Bank>(this.baseUrl + '/GetBankById?id=' + id, this.httpOptions)
      .pipe(
        catchError((error) => {

          return throwError(error);
        })
      )
  }
  getById(id: string) {
    return this.http.get<Bank>(this.baseUrl + `/${id}`, this.httpOptions);
  }

  public myBankList: Bank[] = [];

  //get single user
  singleuserdata: any;
  public getAllBank() {
    return this.http.get<Bank[]>(this.baseUrl + '/GetAllBank')
      .subscribe((res: Bank[]) => {
        this.changeMessage(JSON.stringify(res));

        this.myBankList = res;
      }, error => { 
      });
  }
  GetAllBank(): Observable<Bank[]> {
    return this.http.get<Bank[]>(this.baseUrl + '/GetAllBank', this.httpOptions)
      .pipe(
        catchError((error) => {
          return throwError(error);
        })
      )
  }

  GetAllBank1(): Observable<Bank[]> {
    return this.http.get<Bank[]>(this.baseUrl + '/GetAllBank', this.httpOptions);
  }

  ExportExcel(fileName: string) {
    this.http.get(this.baseUrl + '/ExportExcel', { responseType: 'blob' })
      .subscribe((data: any) => {
        const file: Blob = new Blob([data], {
          type: "application/xlsx"
        });
        //saveAs(file, fileName + '.xlsx');
      },(error) => {
        return throwError(error);
      })
  }
  createEmployee(employee: Bank): Observable<Bank> {

    return this.http.post<Bank>(this.baseUrl + '/CreateBank/',
      employee, this.httpOptions);
  }
  RegisterBank(bank:any) {
    bank.Status = bank.Status == 'A' ? true : false;

    return this.http.post(this.baseUrl + `/CreateBank`, bank);
  }

  update(id:any, params:any) { 
    params.Status = params.Status == 'A' ? true : false;
    return this.http.put(this.baseUrl + `/UpdateBank?id=${id}`, params, this.httpOptions)
      .pipe(map(x => {
        // update stored user if the logged in user updated their own record
        // if (id == this.userValue.id) {
        //     // update local storage
        //     const user = { ...this.userValue, ...params };
        //     localStorage.setItem('user', JSON.stringify(user));

        //     // publish updated user to subscribers
        //     this.userSubject.next(user);
        // }
        return x;
      }));
  }
  create(bank: Bank): Observable<Bank> {

    return this.http.post<Bank>(this.baseUrl + '/CreateBank', JSON.stringify(bank), this.httpOptions)
      .pipe(
        catchError((error) => {
          return throwError(error);
        })
      )

    // if (bank.Bank_ID === null || bank.Bank_ID == 0) {

    // } else {

    //   // this.getCustomer().subscribe(res => {
    //   //   const foundIndex = res.findIndex(e => e.Bank_ID === bank.Bank_ID);
    //   //   res[foundIndex] = bank;
    //   // })
    // }

  }
  delete1(id:any) {
    return this.http.delete<Bank>(this.baseUrl + '/DeleteBank?id=' + id, this.httpOptions)
      .pipe(
        catchError((error) => {      

          return throwError(error);
        })
      )
  }
  delete(id: string) {
    return this.http.delete(this.baseUrl + `/${id}`)
      .pipe(map(x => {
        // auto logout if the logged in user deleted their own record 
        return x;
      }));
  }


  private messageSource = new BehaviorSubject('default message');
  currentMessage = this.messageSource.asObservable();
  changeMessage(message: string) {
    this.messageSource.next(message)
  }

}
