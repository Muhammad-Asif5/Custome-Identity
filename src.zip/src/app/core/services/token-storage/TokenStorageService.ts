import { Injectable } from '@angular/core';
import { LocalItems } from '../..';

@Injectable({
  providedIn: 'root'
})
export class TokenStorageService {
  
  constructor() { }

  SignOut(): void {
    window.localStorage.clear();
    localStorage.removeItem(LocalItems.USER_INFO);
    localStorage.removeItem(LocalItems.TOKEN_KEY);
    localStorage.removeItem(LocalItems.REFRESHTOKEN_KEY);
  }

  public SaveToken(token: string): void {
    window.localStorage.removeItem(LocalItems.TOKEN_KEY);
    window.localStorage.setItem(LocalItems.TOKEN_KEY, token);
  }
  public SaveUser(user: any): void {
    window.localStorage.removeItem(LocalItems.USER_INFO);
    window.localStorage.setItem(LocalItems.USER_INFO, JSON.stringify(user));
  }
  public GetToken(): string | null {
    return window.localStorage.getItem(LocalItems.TOKEN_KEY);
  }
  public GetUser(): string | null {
    return window.localStorage.getItem(LocalItems.USER_INFO);
  }

  public SaveRefreshToken(token: string): void {
    window.localStorage.removeItem(LocalItems.REFRESHTOKEN_KEY);
    window.localStorage.setItem(LocalItems.REFRESHTOKEN_KEY, token);
  }

  public GetRefreshToken(): string | null {
    return window.localStorage.getItem(LocalItems.REFRESHTOKEN_KEY);
  }



  
}
