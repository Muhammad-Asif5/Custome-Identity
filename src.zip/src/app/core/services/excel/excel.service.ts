import { Injectable } from '@angular/core';
import { Workbook } from 'exceljs';
 import * as fs from 'file-saver';
import { DatePipe } from '@angular/common';


@Injectable({
  providedIn: 'root'
})
export class ExcelService {

  constructor(private datePipe: DatePipe) {

  }

  async GenerateExcel(header: string[], data: string[], title: string, sheetName: string, fileName: string) {
    debugger
    const COLUMN = this.GetMerge(header);
    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheet = workbook.addWorksheet(sheetName);


    // Add Row and formatting
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: 'Comic Sans MS', family: 4, size: 16, underline: 'double', bold: true };
    worksheet.mergeCells(`A${titleRow.number}:` + COLUMN + `${titleRow.number}`);

    worksheet.addRow([]);
    const subTitleRow = worksheet.addRow(['Date : ' + this.datePipe.transform(new Date(), 'medium')]);
    worksheet.mergeCells(`A${subTitleRow.number}:` + COLUMN + `${subTitleRow.number}`);

    // Add Image
    //const logo = workbook.addImage({
    //  base64: logoFile.logoBase64,
    //  extension: 'png',
    //});

    //worksheet.addImage(logo, 'D1:E3');
    //worksheet.mergeCells('A1:C2');

    // Blank Row
    worksheet.addRow([]);

    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFF00' },
        bgColor: { argb: 'FF0000FF' }
      };
      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
    });
    // worksheet.addRows(data);


    // Add Data and Conditional Formatting

    data.forEach((d: any) => {

      const DATA = d.bank_ID;
      const DATA1 = d.bank_Name;
      const DATA2 = d.status == true ? 'Active' : 'Closed';
      const dd = [DATA, DATA1, DATA2];

      const row = worksheet.addRow(dd);
      // const qty = row.getCell(5);
      // let color = 'FF99FF99';
      // if (+qty.value < 500) {
      //   color = 'FF9999';
      // }

      // qty.fill = {
      //   type: 'pattern',
      //   pattern: 'solid',
      //   fgColor: { argb: color }
      // };
    }

    );

    //worksheet.getColumn(3).width = 30; //set width of column 
    //worksheet.getColumn(4).width = 30; //set width of column 

    worksheet.addRow([]);


    // Footer Row
    const footerRow = worksheet.addRow(['This is system generated excel sheet.']);
    footerRow.getCell(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFCCFFE5' }
    };
    footerRow.getCell(1).border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };

    // Merge Cells
    debugger

    worksheet.mergeCells(`A${footerRow.number}:` + COLUMN + `${footerRow.number}`);

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, fileName + '.xlsx');
    });

  }

  GetMerge(header:any): string {
    var alphabet = [];
    alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    return alphabet[header.length - 1];
  }
}
