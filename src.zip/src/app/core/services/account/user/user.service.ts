import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor() { }

  public userName: string;
  public userType: string;
  public userId: string;
  public id: number;
  public roles: string[];
  public isLoggedIn :Boolean = false;

  SetUser(userId: string,userName: string,userType: string, roles: string[]) {
    
    this.userId =userId
    this.userName = userName;
    this.userType=userType;
    this.roles = roles;
    this.isLoggedIn = true
  }

 
}
