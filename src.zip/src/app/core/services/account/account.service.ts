import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, Observable,ReplaySubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { AuthResponse, User } from '../../models';
import { TokenStorageService } from '../token-storage/TokenStorageService';
import { UserService } from './user/user.service';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  //private userSubject$: BehaviorSubject<AuthResponse>;
  //public user: Observable<AuthResponse>;
  private currentUserSource = new ReplaySubject<AuthResponse>(1);
  currentUser$ = this.currentUserSource.asObservable();

  constructor(private router: Router, private http: HttpClient,
    private tokenStorageService: TokenStorageService,
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private jwtHelperService: JwtHelperService) {
    //this.userSubject$ = new BehaviorSubject<AuthResponse>(JSON.parse(localStorage.getItem('user')));
    // this.user = this.userSubject$.asObservable();
  }

  //public get userValue(): AuthResponse {
  //  return this.userSubject$.value;
  //}
  private baseUrl = `${environment.apiUrl}/Account`;
  httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
  login2(parms: any): Observable<AuthResponse> {

    return this.http.post<AuthResponse>(this.baseUrl + '/Login/', parms, this.httpOptions);
  }

  //#region Login

  login(parms: any) {

    return this.http.post<AuthResponse>(this.baseUrl + '/Login/', parms, this.httpOptions).pipe(
        map((user:AuthResponse) => {
        // store user details and jwt token in local storage to keep user logged in between page refreshes
        //this.utilitiesService.SetLocalTime(LocalItems.TOKEN_KEY, user.token, 30 * 24 * 60);   
        this.tokenStorageService.SaveToken(user.token);
        this.tokenStorageService.SaveRefreshToken(user.refreshToken);
        this.tokenStorageService.SaveUser(user);
        //this.userSubject$.next(user);
        //this.userInitialization();
        this.currentUserSource.next(user);
        return user;
      }));
  }

  //#endregion


  //#region Generate Refresh Token

  isAuthenticated: boolean;
  async GenerateRefreshToken(tokenModel: any) {
    return await this.http.post(this.baseUrl + '/RefreshToken', tokenModel, this.httpOptions).subscribe((response: any) => {

      localStorage.clear();
      const newToken = response.accessToken;
      const newRefreshToken = response.refreshToken;
      this.tokenStorageService.SaveToken(newToken);
      this.tokenStorageService.SaveRefreshToken(newRefreshToken);
      this.tokenStorageService.SaveUser(response);

      //this.userSubject$.next(response);
      //this.userInitialization();
      return response;
    });
  }


  GenerateRefreshToken2(token: any) {
    return this.http.post(this.baseUrl + '/RefreshToken', token, this.httpOptions);
  }

  //#endregion


  logout() {
    // remove user from local storage and set current user to null
    this.tokenStorageService.SignOut();
    //this.userSubject$.next(null);
    //const URL = this.activatedRoute.snapshot['_routerState'].url
    this.router.navigate(['/account/login'], { queryParams: { returnUrl: URL } });
  }


  //#region Get User

  userInfo: User;
  public GetUser(): User {

    this.userInfo = {
      userId: '',
      userName: '',
      userType: '',
      userRole: [],
      isAuthenticated: false
    };
    
    var token = this.tokenStorageService.GetToken();    
    if (token != null ) {      
      const userData: any = this.jwtHelperService.decodeToken(token);
      if (!userData) {
        console.log("Invalid Token");
        return this.userInfo;
      }
      var myRole = userData['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
      var userId = userData['http://schemas.microsoft.com/ws/2008/06/identity/claims/sid'];

      this.userService.SetUser(userId, userData.UserName, userData.UserType, myRole);
      this.userInfo.userId = this.userService.userId
      this.userInfo.userName = this.userService.userName;
      this.userInfo.userType = this.userService.userType

      this.userInfo.userRole = this.userService.roles;
      this.userInfo.isAuthenticated = true;

      return this.userInfo;

    }
    return this.userInfo;
  }

  //#endregion


}
