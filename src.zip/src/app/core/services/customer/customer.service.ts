import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, Subject, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Customer } from '../../models/customer/customer';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  subject: Subject<Object> = new Subject<Object>();
  
  private baseUrl = `${environment.apiUrl}/Customer`;
  myClassBinding: string;
  RegisterBtn: string;
  constructor(private http: HttpClient) { }
  httpOptions = {  
    headers: new HttpHeaders({  
      'Content-Type': 'application/json'  
    })  
  }    

  GetCustomer(): Observable<any[]> {
    return this.http.get<Customer[]>(this.baseUrl + '/GetAllCustomer')
      .pipe(
        catchError((error) => {
          return throwError(error);
        }) 
      )
  }
  getById(id: string) {
    return this.http.get<Customer>(this.baseUrl + `/${id}`, this.httpOptions);
  }
  LoadAllEmployee():Observable<object>{ 
    return this.http.get(this.baseUrl + 'GetAllCustomer');
  }
  AddBank(bank:any) {
    bank.Status = bank.Status == 'A' ? true : false;

    return this.http.post(this.baseUrl + `/CreateCustomer`, bank);
  }

  update(id:any, params:any) { 
    params.Status = params.Status == 'A' ? true : false;
    return this.http.put(this.baseUrl + `/UpdateCustomer?id=${id}`, params, this.httpOptions)
      .pipe(map(x => {
        // update stored user if the logged in user updated their own record
        // if (id == this.userValue.id) {
        //     // update local storage
        //     const user = { ...this.userValue, ...params };
        //     localStorage.setItem('user', JSON.stringify(user));

        //     // publish updated user to subscribers
        //     this.userSubject.next(user);
        // }
        return x;
      }));
  }
 
}
