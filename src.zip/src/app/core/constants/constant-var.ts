export const URLS = {
    mainboard: {
      default: '/Mainboard',
      dashboard: '/dashboard',
      allAirline: '/all-airline',
      //createSegment: 'createSegment'
    },
    auth: {
      login: '/login',
      forgetPassword:'/ForgetPassword'
    },
    Hss: "/login"
  }
  
  export enum Controllers {
    Authentication = "Auth/",
    ContactList = "ContactList/",
  }
  
  export const LocalItems = {
    //Token : "token",
    RememberMe : "rememberme",
    ResetPassword: "resetpassword",
  
    TOKEN_KEY         : 'token',
    REFRESHTOKEN_KEY  : 'refreshToken',
    USER_INFO         : 'user',
  }
  
  