import { Pipe, PipeTransform } from "@angular/core";
import { Bank } from "../models/bank/bank";

@Pipe({ name: "searchBank" })
export class BankPipe implements PipeTransform {
    transform(values: Bank[], filter: string): Bank[] {
        if (!filter || filter.length === 0) {
            return values;
        }

        if (values.length === 0) {
            return values;
        }

        return values.filter((value: Bank) => {
            const nameFound = value.bank_Name.toLowerCase().indexOf(filter.toLowerCase()) !== -1;
            const capitalFound = value.bank_Name.toLowerCase().indexOf(filter.toLowerCase()) !== -1;
            if (nameFound || capitalFound) {
                return value;
            }
        });
    }
}
