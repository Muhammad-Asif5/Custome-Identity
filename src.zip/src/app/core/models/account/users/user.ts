export class User{
    userId   :string;
    userName: string;
    userType:string;
    userRole :string[];
    isAuthenticated:Boolean
}

export enum Role{
    Admin = "Admin",
    
}