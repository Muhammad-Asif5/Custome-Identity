export class AuthResponse {
    id: string;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    token: string;
    refreshToken: string;
    isAuthSuccessful: boolean;
    errorMessage: string;
}


 