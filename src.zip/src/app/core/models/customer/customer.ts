

export class Customer
{
    cust_ID :number;
    lookup :string;
    cust_Code :string;
    company_Name :string;
    contact_Name :string;
    address :string;
    city :string;
    state :string;
    zIP_Code :string;
    phone :string;
    email :string;
    fax :string;
}


// export class User{
//     username: string;
//     password:string;
//   }