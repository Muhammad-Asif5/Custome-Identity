export class Bank {
    bank_ID:	number;
    bank_Name:	string;
    status:	string;
    isDeleting: string ;
    isEditing: string ;
}
