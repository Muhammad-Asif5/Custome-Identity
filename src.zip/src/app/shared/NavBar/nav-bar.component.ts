import { Component, OnInit } from '@angular/core'; 
import { AccountService } from 'src/app/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.sass']
})
export class NavBarComponent implements OnInit {

  constructor(private accountService: AccountService) { }

  ngOnInit(): void {
  }

  logout(){
    debugger
    this.accountService.currentUser$.subscribe(user=>{
      
    })
    this.accountService.logout();
  }
}
