import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AccountService, AuthResponse, User } from 'src/app/core';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.sass']
})
export class SideBarComponent implements OnInit {

  constructor(public accountService: AccountService) { }

  username:string;
  ngOnInit(): void {
   this.username = this.accountService.GetUser().userName;
  }


}
