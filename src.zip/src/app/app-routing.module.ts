import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core';
import { AuthComponent } from './modules/auth/auth.component';
import { NotFoundComponent } from './not-found/not-found.component';

 
const routes: Routes = [
  { path: '', component: AuthComponent, loadChildren: () => import('./modules/auth/auth.module').then(x => x.AuthModule) },
  //{ path: '', redirectTo: '/login' ,pathMatch:'full' } ,
  { path: '',canActivate:[AuthGuard], loadChildren: () => import('./modules/generals/general.module').then(x => x.GeneralModule)},   
  
  { path: '404', component: NotFoundComponent }, 
  { path: '**', redirectTo: '404' }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
