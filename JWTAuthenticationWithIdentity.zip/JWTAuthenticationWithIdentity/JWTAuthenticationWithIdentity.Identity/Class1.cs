﻿using System;

namespace JWTAuthenticationWithIdentity.Identity
{
    public class Class1
    {
    }
}
