﻿
using JWTAuthenticationWithIdentity.Models.AuthenticateResponse;
using System;
using System.Collections.Generic;

namespace JWTAuthenticationWithIdentity.Models
{
    public class MessageViewModel
    {
        public string message { get; set; }
        public DateTime currentDate { get; set; }
        public List<Response> errorMessage { get; set; }
        public MessageViewModel(string message, DateTime currentDate, List<Response> errorMessage)
        {
            this.message = message;
            this.currentDate = currentDate;
            this.errorMessage = errorMessage;
        }
    }
}
