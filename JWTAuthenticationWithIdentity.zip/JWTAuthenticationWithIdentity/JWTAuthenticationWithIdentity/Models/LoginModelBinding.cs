﻿using System;
using System.ComponentModel.DataAnnotations;

namespace JWTAuthenticationWithIdentity.Models
{
    public class LoginModelBinding
    {
        [Required(ErrorMessage = "User Name is required")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Email address is required")]
        [EmailAddress]
        public string Email { get; set; }
        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }
    }
}
