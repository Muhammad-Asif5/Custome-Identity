﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using JWTAuthenticationWithIdentity.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace JWTAuthenticationWithIdentity.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthCosntroller : ControllerBase
    {
        //NOT GOOD
        [HttpPost, Route("login")]
        public IActionResult Login([FromBody] LoginModelBinding user)
        {
            if (user == null)
                return BadRequest("Invalid Client Request");
            if (user.Username == "athar.ahmed" && user.Password == "Athar@123")
            {

                var sceretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSceretKey@345"));
                var signingCredentials = new SigningCredentials(sceretKey, SecurityAlgorithms.HmacSha256);

                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.Username),
                    new Claim(ClaimTypes.Role, "Manager"),
                    new Claim(ClaimTypes.Role, "Admin")
                };

                var tokenOptions = new JwtSecurityToken(
                    claims: claims,
                    expires: DateTime.Now.AddSeconds(60),
                    signingCredentials: signingCredentials
                    );
                var tokenString = new JwtSecurityTokenHandler().WriteToken(tokenOptions);

                return Ok(new { Token = tokenString });
            }
            return Unauthorized();
        }

        [Authorize]
        [HttpGet, Route("GetMe")]
        public string GetMe()
        {
            return "Okay";
        }


    }
}
