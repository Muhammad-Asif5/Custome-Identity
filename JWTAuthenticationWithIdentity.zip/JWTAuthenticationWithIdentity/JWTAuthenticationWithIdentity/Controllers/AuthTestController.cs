﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using JWTAuthenticationWithIdentity.Core.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace JWTAuthenticationWithIdentity.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthTestController : BaseController
    {
        //public AuthTestController(UserManager<ApplicationUser> userManager,
        //                        RoleManager<ApplicationRole> roleManager,
        //                        SignInManager<ApplicationUser> signInManager,
        //                        IConfiguration configuration):base (userManager, roleManager, signInManager, configuration)
        //{


        //}

        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<ApplicationRole> roleManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly IConfiguration _configuration;

        public AuthTestController(UserManager<ApplicationUser> userManager,
                                RoleManager<ApplicationRole> roleManager,
                                SignInManager<ApplicationUser> signInManager,
                                IConfiguration configuration)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            this.signInManager = signInManager;
            _configuration = configuration;
        }


        [HttpGet]
        public ApplicationUser GetUserProfile()
        {
            var currentUser = User.Identity;
            var Username = User.GetClaimValue(ClaimTypes.Name);
            var Email = User.GetClaimValue("Email");

            var newUser = UserProfileAsync();
            return newUser;
        }

        

    }
}
