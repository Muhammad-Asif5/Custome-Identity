﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using JWTAuthenticationWithIdentity.Core.Context;
using JWTAuthenticationWithIdentity.Models;
using JWTAuthenticationWithIdentity.Models.AuthenticateResponse;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace JWTAuthenticationWithIdentity.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<ApplicationRole> roleManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly IConfiguration _configuration;

        public AccountController(UserManager<ApplicationUser> userManager, 
                                RoleManager<ApplicationRole> roleManager,
                                SignInManager<ApplicationUser> signInManager,
                                IConfiguration configuration)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            this.signInManager = signInManager;
            _configuration = configuration;
        }


        [HttpGet]
        [Route("DDLAllUsers")]
        public async Task<IEnumerable<ApplicationUser>> DDLAllUsers()
        {
            IEnumerable<ApplicationUser> allUser = userManager.Users.ToList();
            return allUser;
        }
        [HttpGet]
        [Route("DDLAllRole")]
        public IEnumerable<ApplicationRole> DDLAllRole()
        {
            IEnumerable<ApplicationRole> allRoles = roleManager.Roles.ToList();
            return allRoles;
        }
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] LoginModelBinding model)
        {
            if (!ModelState.IsValid)
            {
                IEnumerable<ModelError> allError = ModelState.Values.SelectMany(x => x.Errors);
                var errors = (from item in allError
                              select new
                              {
                                  item.ErrorMessage,
                                  item.Exception
                              }).ToList();
                //return Request.CreateResponse(HttpStatusCode.OK, error);
                return BadRequest(new { HttpStatusCode.OK, errors });
            }
            else
            {
                var user = await userManager.FindByEmailAsync(model.Email);
                if (user==null)
                {
                    return Unauthorized("Email "+model.Email+" Not Found");
                }
                
                if (user != null && !user.EmailConfirmed &&
                    (await userManager.CheckPasswordAsync(user, model.Password)))
                {
                    return Unauthorized("Email Not Confirmed");
                }
                else if (user != null &&
                    (await userManager.CheckPasswordAsync(user, model.Password)) &&
                    (await userManager.IsLockedOutAsync(user)))
                {
                    return Unauthorized("Your account is locked out. Kindly wait for 10 minutes and try again");
                }
                else if (user != null && await userManager.CheckPasswordAsync(user, model.Password))
                {

                    var authClaims = await GetAllValidClaims(user);
                    var token = GenerateJwtToken(authClaims);

                    //var claims = await GetAllValidClaims(user);
                    //var jwtTokenHandler = new JwtSecurityTokenHandler();
                    //var key = Encoding.UTF8.GetBytes(_configuration["AppSettings:Secret"]);
                    //var tokenValidityInMinutes = int.Parse(_configuration["AppSettings:TokenValidityInMinutes"]);
                    ////var signingCredentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    //var tokenDescriptor = new SecurityTokenDescriptor
                    //{
                    //    Subject = new ClaimsIdentity(claims),
                    //    Expires = DateTime.UtcNow.AddSeconds(30),
                    //    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256)
                    //};
                    //var toke = jwtTokenHandler.CreateToken(tokenDescriptor);
                    //var jwtToken = jwtTokenHandler.WriteToken(toke);

                    var refreshToken = GenerateRefreshToken();

                    _ = int.TryParse(_configuration["AppSettings:RefreshTokenValidityInDays"], out int refreshTokenValidityInDays);

                    user.RefreshToken = refreshToken;
                    user.RefreshTokenExpiryTime = DateTime.Now.AddMinutes(refreshTokenValidityInDays);

                    await userManager.ResetAccessFailedCountAsync(user);
                    await userManager.UpdateAsync(user);

                    var cookieOptions = new CookieOptions
                    {
                        HttpOnly = true,
                        //Expires = DateTime.UtcNow.AddSeconds(10)
                        Expires = DateTime.Now.AddDays(refreshTokenValidityInDays)
                    };
                    Response.Cookies.Append("refreshToken", refreshToken, cookieOptions);
                    Response.Cookies.Append("accessToken",
                        new JwtSecurityTokenHandler().WriteToken(token), cookieOptions);

                    return Ok(new
                    {
                        Token = new JwtSecurityTokenHandler().WriteToken(token),
                        RefreshToken = refreshToken,
                        Expiration = token.ValidTo.ToString("dd/mm/yyy hh:mm:ss tt"),
                        Created = DateTime.Now.ToString("dd/mm/yyy hh:mm:ss tt")
                    });
                }
                else
                {
                    if (user != null && await userManager.IsLockedOutAsync(user))
                    {
                        return Ok("Your account is locked out. Kindly wait for 10 minutes and try again");
                    }
                    else
                    {
                        var result = await userManager.AccessFailedAsync(user);
                        //await userManager.SetLockoutEnabledAsync(user, true);
                        //await userManager.UpdateAsync(user);
                        return Unauthorized("Invalid Login Attempt");
                    }

                }
            }
        }
        private async Task<List<Claim>> GetAllValidClaims(ApplicationUser user)
        {
            var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Sid, user.Id),
                    new Claim(ClaimTypes.Name, user.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim("UserName", user.UserName),
                    new Claim("Email", user.Email),
                    new Claim("Password", user.PasswordHash)
                };

            var userRoles = await userManager.GetRolesAsync(user);
            foreach (var userRole in userRoles)
            {
                authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                //authClaims.Add(new Claim("role", userRole));
            }
            return authClaims;
        }
        private async Task<List<Claim>> GetAllValidClaims1(ApplicationUser user)
        {
            var _option = new IdentityOptions();
            var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Sid, user.Id),
                    new Claim(ClaimTypes.Name, user.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim("UserName", user.UserName),
                    new Claim("Email", user.Email)
                };
            
            var userClaims =await userManager.GetClaimsAsync(user);
            claims.AddRange(userClaims);

            var userRoles = await userManager.GetRolesAsync(user);
            foreach (var userRole in userRoles)
            {
                var role = await roleManager.FindByNameAsync(userRole);
                if (role != null)
                {
                    claims.Add(new Claim(ClaimTypes.Role, userRole));

                    var roleClaims = await roleManager.GetClaimsAsync(role);
                    foreach (var roleClaim in roleClaims)
                    {
                        claims.Add(roleClaim);

                    }
                }
            }
            return claims;
        }

        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModelBinding model)
        {
            List<Response> errorKeys = null;
            if (ModelState.IsValid)
            {
                var userExists = await userManager.FindByNameAsync(model.Username);
                if (userExists != null)
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User " + model.Username + " already exists!" });
               
                var user = new ApplicationUser
                {
                    Email = model.Email,
                    SecurityStamp = Guid.NewGuid().ToString(),
                    UserName = model.Username
                };
                //// Performs v3 PBKDF2 hash of provided MD5 hash
                //var reHashedPassword = userManager.PasswordHasher.HashPassword(user, model.Password);

                var result = await userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    var token = await userManager.GenerateEmailConfirmationTokenAsync(user);
                    var confirmationLink = Url.Action("ConfirmEmail", "Account",
                                            new { userId = user.Id, token = token }, Request.Scheme);


                    return Ok(new Response { Status = "Success", Message = "User created successfully!" });
                }
                else
                {

                    errorKeys = (from item in result.Errors
                                 select new Response
                                 {
                                     Message = item.Description,
                                     Status = item.Code
                                 }).ToList();
                    //return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = errorKeys[0].Message });
                }
            }
            return BadRequest(new MessageViewModel("Registration failed.", DateTime.Now, errorKeys));

        }
        [HttpPost]
        [Route("ConfirmEmail")]
        public async Task<IActionResult> ConfirmEmail(string userId, string token)
        {
            if (userId == null || token == null)
            {
                return RedirectToAction("index", "home");
            }

            var user = await userManager.FindByIdAsync(userId);

            if (user == null)
            {
                return NotFound($"The User ID {userId} is invalid");
            }

            var result = await userManager.ConfirmEmailAsync(user, token);

            if (result.Succeeded)
            {
                return Ok();
            }
            var errors = (from q in result.Errors
                          select new { q.Description, q.Code }).ToList();
            return NotFound($"Email cannot be confirmed / " + errors[0].Description);
        }

        private JwtSecurityToken GenerateJwtToken(List<Claim> authClaims)
        {
            var sceretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["AppSettings:Secret"]));
            var tokenValidityInMinutes = int.Parse(_configuration["AppSettings:TokenValidityInMinutes"]);
            var signingCredentials = new SigningCredentials(sceretKey, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                claims: authClaims,
                expires: DateTime.UtcNow.AddMinutes(10),
                //expires: DateTime.UtcNow.AddMinutes(tokenValidityInMinutes),
                signingCredentials: signingCredentials
                );

            return token;
        }
   
        private JwtSecurityToken generateJwtToken1(List<Claim> authClaims)
        {
            // generate token that is valid for 3 Hours
            var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));
            _ = int.TryParse(_configuration["JWT:TokenValidityInMinutes"], out int tokenValidityInMinutes);

            //var tokenHandler = new JwtSecurityTokenHandler();
            var token = new JwtSecurityToken(
                      //issuer: _configuration["JWT:ValidIssuer"],
                      //audience: _configuration["JWT:ValidAudience"],
                      //expires: DateTime.Now.AddHours(3),
                      expires: DateTime.UtcNow.AddMinutes(tokenValidityInMinutes),
                      claims: authClaims,
                      signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                      );

            //return tokenHandler.WriteToken(token);
            return token;
        }
        private static string GenerateRefreshToken()
        {
            var randomNumber = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }

        private ClaimsPrincipal? GetPrincipalFromExpiredToken(string? token)
        {
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["AppSettings:Secret"])),
                ValidateLifetime = false
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out SecurityToken securityToken);
            if (securityToken is not JwtSecurityToken jwtSecurityToken || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                throw new SecurityTokenException("Invalid token");

            return principal;

        }

        [HttpPost]
        [Route("register-admin")]
        public async Task<IActionResult> RegisterAdmin([FromBody] RegisterModelBinding model)
        {
            var userExists = await userManager.FindByNameAsync(model.Username);
            if (userExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already exists!" });

            ApplicationUser user = new ApplicationUser()
            {
                Email = model.Email,
                SecurityStamp = Guid.NewGuid().ToString(),
                UserName = model.Username
            }; 
            var result = await userManager.CreateAsync(user, model.Password);
            if (!result.Succeeded)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User creation failed! Please check user details and try again." });

            if (!await roleManager.RoleExistsAsync("Administrator"))
                await roleManager.CreateAsync(new ApplicationRole("Administrator"));
            if (!await roleManager.RoleExistsAsync("User"))
                await roleManager.CreateAsync(new ApplicationRole("User"));

            if (await roleManager.RoleExistsAsync("Administrator"))
            {
                await userManager.AddToRoleAsync(user, "Administrator");
            }

            return Ok(new Response { Status = "Success", Message = "User created successfully!" });
        }
        [HttpPost]
        [Route("RefreshToken")]
        public async Task<IActionResult> RefreshToken(TokenModel tokenModel)
        {
            if (tokenModel is null)
            {
                return BadRequest("Invalid client request");
            }

            string? accessToken = tokenModel.AccessToken;
            string? refreshToken = tokenModel.RefreshToken;

            var principal = GetPrincipalFromExpiredToken(accessToken);
            if (principal == null)
            {
                return BadRequest("Invalid access token or refresh token");
            }

                #pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
                #pragma warning disable CS8602 // Dereference of a possibly null reference.
                            string username = principal.Identity.Name;
                #pragma warning restore CS8602 // Dereference of a possibly null reference.
                #pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.

            var user = await userManager.FindByNameAsync(username);

            //if (user == null || user.RefreshToken != refreshToken || user.RefreshTokenExpiryTime <= DateTime.Now)
            //{
            //    return BadRequest("Invalid access token or refresh token");
            //}

            var newAccessToken = GenerateJwtToken(principal.Claims.ToList());
            var newRefreshToken = GenerateRefreshToken();

            user.RefreshToken = newRefreshToken;
            await userManager.UpdateAsync(user);

            return new ObjectResult(new
            {
                accessToken = new JwtSecurityTokenHandler().WriteToken(newAccessToken),
                refreshToken = newRefreshToken
            });
        }
        [HttpPost]
        [Route("RefreshToken2")]
        public async Task<IActionResult> RefreshToken2()
        {
            var refreshToken = Request.Cookies["refreshToken"];
            var accessToken = Request.Cookies["accessToken"];

            var principal = GetPrincipalFromExpiredToken(accessToken);
            var username = principal.Identity.Name;
            var user = await userManager.FindByNameAsync(username);

            if (!user.RefreshToken.Equals(refreshToken))
            {
                return Unauthorized("Invalid access token or refresh token");
            }
            else if (user.RefreshTokenExpiryTime < DateTime.Now)
            {
                return Unauthorized("Token Expired");
            } 

            var newAccessToken = GenerateJwtToken(principal.Claims.ToList());
            var newRefreshToken = GenerateRefreshToken();

            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.Now.AddDays(7)
            };
            Response.Cookies.Delete("refreshToken");
            Response.Cookies.Delete("accessToken");
            Response.Cookies.Append("refreshToken", newRefreshToken, cookieOptions);
            Response.Cookies.Append("accessToken",
                   new JwtSecurityTokenHandler().WriteToken(newAccessToken), cookieOptions);

            user.RefreshToken = newRefreshToken;
            await userManager.UpdateAsync(user);

            return new ObjectResult(new
            {
                accessToken = new JwtSecurityTokenHandler().WriteToken(newAccessToken),
                refreshToken = newRefreshToken
            });
        }

    }
}
