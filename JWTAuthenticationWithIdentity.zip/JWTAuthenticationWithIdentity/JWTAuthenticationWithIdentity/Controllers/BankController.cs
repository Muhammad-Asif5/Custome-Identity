﻿using System;
using System.Net;
using System.Threading.Tasks;
using JWTAuthenticationWithIdentity.Models.Banks;
using JWTAuthenticationWithIdentity.Services.Banks;
using Microsoft.AspNetCore.Authorization; 
using Microsoft.AspNetCore.Mvc;

namespace JWTAuthenticationWithIdentity.Controllers
{
    [Authorize]
    [Route("api/Bank")]
    [ApiController]
    public class BankController : ControllerBase
    {
        private readonly IBankService _BankService;
        public BankController(IBankService BankService)
        {
            _BankService = BankService;
        }
       // [Authorize(Roles = "Add New Customer")]
        [HttpGet, Route("GetAllBank")]
        public async Task<IActionResult> GetAllBank()
        {
            try
            {
                var currentUser = User.Identity;

                var banks = await _BankService.GetAllBankAsync();
                return  Ok(banks);
            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }
        }
        // [Authorize(Roles = "Admin")]
        [HttpGet("{id}")]
        //[Route("GetBankById")]
        public async Task<IActionResult> GetBankById(int id)
        {
            try
            {
                var bank = await _BankService.GetBankByIdAsync(id);
                if (bank == null)
                    return NotFound();
                return Ok(bank);
            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost, Route("CreateBank")]
        public async Task<IActionResult> CreateBank(Bank model)
        {
            try
            {
                var bank = await _BankService.CreateBankAsync(model);
                if (bank == null)
                    return NotFound();
                return Ok(bank);
            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }
        }
        [HttpPut, Route("UpdateBank")]
        public async Task<IActionResult> UpdateCompany(int id, Bank model)
        {
            try
            {
                var bank = await _BankService.GetBankByIdAsync(id);
                if (bank == null)
                    return NotFound();

                await _BankService.UpdateBankAsync(id, model);
                return new OkObjectResult(new Bank { Bank_ID = model.Bank_ID, Bank_Name = model.Bank_Name});
            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBank(int id)
        {
            try
            {
                var bank = await _BankService.GetBankByIdAsync(id);
                if (bank == null)
                    return NotFound();
                await _BankService.DeleteBankAsync(id);
                return new OkObjectResult(new {message="Success" });
            }
            catch (Exception ex)
            {
                //log error
                return StatusCode(500, ex.Message);
            }
        }
    }
}
