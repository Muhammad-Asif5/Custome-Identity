﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using JWTAuthenticationWithIdentity.Core.Context;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace JWTAuthenticationWithIdentity.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseController : ControllerBase
    {
        //private readonly UserManager<ApplicationUser> userManager;
        //private readonly RoleManager<ApplicationRole> roleManager;
        //private readonly SignInManager<ApplicationUser> signInManager;
        //private readonly IConfiguration _configuration;
        //public BaseController(UserManager<ApplicationUser> userManager,
        //                        RoleManager<ApplicationRole> roleManager,
        //                        SignInManager<ApplicationUser> signInManager,
        //                        IConfiguration configuration)
        //{
        //    this.userManager = userManager;
        //    this.roleManager = roleManager;
        //    this.signInManager = signInManager;
        //    _configuration = configuration;

        //}
         

        [NonAction]
        public ApplicationUser UserProfileAsync()
        {
            string response = Request.Headers["Authorization"];
            var token = response.Split(' ')[1];           
           // StringBuilder sb = new StringBuilder();
            List<Claim> roles = new List<Claim>();
            ApplicationUser newUser = new ApplicationUser();
            var currentUser = GetPrincipal(token);
            if (currentUser!=null)
            {
                var userName = currentUser.Identity.Name;
                var userClaims = currentUser.Claims.ToList();
                var userId = currentUser.Claims.FirstOrDefault(x => x.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid").Value;
                IEnumerable<Claim> claimss = currentUser.Claims.ToList();
               
                foreach (var item in claimss)
                {
                    if (item.Type.Split('/').LastOrDefault() == "role")
                    {
                        //sb.Append(item.Value);
                        //sb.Append(",");
                        //roles.Add(new Claim(ClaimTypes.Role as string, item.Value as string));
                        roles.Add(new Claim("roles", item.Value as string));              
                    }
                }
                
                //string[] myRoles = sb.ToString().Split(",", StringSplitOptions.RemoveEmptyEntries);

                Dictionary<string, string> headerData = new Dictionary<string, string>();

                foreach (Claim c in claimss)
                {
                    if (c.Type.Split('/').LastOrDefault() != "role")
                    {
                        headerData.Add(c.Type.Split('/').LastOrDefault(), c.Value);
                    }
                }

                newUser.Id = headerData.ElementAt(0).Value;
                newUser.UserName = headerData.ElementAt(3).Value;
                newUser.Email = headerData.ElementAt(4).Value;

                newUser.Claims = roles;
            }
             

            return newUser;
        }
      
        public static ClaimsPrincipal GetPrincipal(string token)
        {

            try
            {
                JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
                JwtSecurityToken jwtToken = (JwtSecurityToken)tokenHandler.ReadToken(token);
                if (jwtToken == null) return null;
                var key = Encoding.ASCII.GetBytes("superSceretKey@345");
                TokenValidationParameters parameters = new TokenValidationParameters()
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                    ClockSkew = TimeSpan.Zero,
                    ValidateLifetime = true
                };
                SecurityToken securityToken;
                ClaimsPrincipal principal = tokenHandler.ValidateToken(token, parameters, out securityToken);
                return principal;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        
        
        //[NonAction]
        //private async Task<List<Claim>> GetAllValidClaims(ApplicationUser user)
        //{
        //    var authClaims = new List<Claim>
        //        {
        //            new Claim(ClaimTypes.Sid, user.Id),
        //            new Claim(ClaimTypes.Name, user.UserName),
        //            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        //            new Claim("UserName", user.UserName),
        //            new Claim("Email", user.Email),
        //            new Claim("Password", user.PasswordHash)
        //        };

        //    var userRoles = await userManager.GetRolesAsync(user);
        //    foreach (var userRole in userRoles)
        //    {
        //        authClaims.Add(new Claim(ClaimTypes.Role, userRole));
        //        //authClaims.Add(new Claim("role", userRole));
        //    }
        //    return authClaims;
        //}

      
    }
}
