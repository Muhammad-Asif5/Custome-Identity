﻿namespace JWTAuthenticationWithIdentity
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}