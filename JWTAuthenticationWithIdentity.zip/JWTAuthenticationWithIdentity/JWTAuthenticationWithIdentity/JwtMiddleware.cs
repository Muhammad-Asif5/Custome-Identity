﻿using JWTAuthenticationWithIdentity.Core.Context;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity
{
    public class JwtMiddleware
    {
        private readonly RequestDelegate _next;
        public Microsoft.Extensions.Configuration.IConfiguration Configuration { get; }
        public JwtMiddleware(RequestDelegate next, Microsoft.Extensions.Configuration.IConfiguration configuration)
        {
            _next = next;
            Configuration = configuration;
        }

        public async Task Invoke(HttpContext context, UserManager<ApplicationUser> _UserManager)
        {
            var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();

            if (token != null)
                attachUserToContext(context, _UserManager, token);

            await _next(context);
        }

        private void attachUserToContext(HttpContext context, UserManager<ApplicationUser> _UserManager, string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(Configuration["AppSettings:Secret"]);
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    //ValidateIssuerSigningKey = true,
                    //ValidateIssuer = false,
                    //ValidateAudience = false,
                    //IssuerSigningKey = new SymmetricSecurityKey(key),
                    ////set clockskew to zero so tokens expire exactly at token expiration time(instead of 5 minutes later)
                    //ClockSkew = TimeSpan.Zero,
                    //ValidateLifetime = true

                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                    ClockSkew = TimeSpan.Zero,
                    ValidateLifetime = true,

                    //ValidIssuer = "http://localhost:61100",
                    //ValidAudience = "http://localhost:61100"

                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                //var userId = int.Parse(jwtToken.Claims.First(x => x.Type == "id").Value);
                var userId = jwtToken.Claims.FirstOrDefault(x => x.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid").Value;
                var userClaims = jwtToken.Claims.ToList();

                // attach user to context on successful jwt validation
                var currentUser = _UserManager.FindByIdAsync(userId).Result;
                currentUser.Claims = userClaims;

                context.Items["User"] = currentUser;

            }
            catch (Exception ex)
            {
                // do nothing if jwt validation fails
                // user is not attached to context so request won't have access to secure routes
            }
        }
    }
}