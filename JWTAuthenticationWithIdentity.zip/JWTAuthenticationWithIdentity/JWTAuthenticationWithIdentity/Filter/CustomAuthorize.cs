﻿
using JWTAuthenticationWithIdentity.Core.Context;
using JWTAuthenticationWithIdentity.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;

namespace JWTAuthenticationWithIdentity.Filter
{
    public class CustomAuthorize : AuthorizeAttribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var result = true;
            if (!context.HttpContext.Request.Headers.ContainsKey("Authorization"))
                result = false;
            string token = string.Empty;
            if (result)
            {
                token = context.HttpContext.Request.Headers.First(x => x.Key == "Authorization").Value;
                //verify token here
            }
            if (!result)
            {
                context.ModelState.AddModelError("Unauthorize", "You are not authorize");
                context.Result = new UnauthorizedObjectResult(context.ModelState);
            }
            var accessToken = context.HttpContext.Request.Query["access_token"];
            var data = context.HttpContext.Request.Headers.ContainsKey("Authorization");
            string response = context.HttpContext.Request.Headers["Authorization"];
            response = response.Replace("Bearer ", "");

            var jwtHandler = new JwtSecurityTokenHandler();
            var jwtInput = response;
            var readableToken = jwtHandler.CanReadToken(jwtInput);
            IEnumerable<Claim> claimss = null;
            if (readableToken)
            {
                var token2 = jwtHandler.ReadJwtToken(jwtInput);
                var claims = token2.Claims;
                claimss = claims;
            }

            //var authHeader = AuthenticationHeaderValue.Parse(context.HttpContext.Request.Headers["Authorization"]);
            //var credentialBytes = Convert.FromBase64String(authHeader.Parameter);
            //var credentials = Encoding.UTF8.GetString(credentialBytes).Split(new[] { ':' }, 2);



            var username = claimss.First(x => x.Type == "UserName").Value; // credentials[0];
            var password = claimss.First(x => x.Type == "Password").Value; //credentials[1];
            var exp = claimss.First(x => x.Type == "exp").Value;
           
            AuthenticateRequest model = new AuthenticateRequest
            {
                Username = "",
                Password = ""
            };


            string redirectUrl = "/Auth/Login";
            var user = (ApplicationUser)context.HttpContext.Items["User"];
            if (user == null)
            { // not logged in
                context.Result = new JsonResult(new { message = "Unauthorized" }) { StatusCode = StatusCodes.Status401Unauthorized };
                //result is returned to AJAX call and user is redirected to sign in page
                JsonResult jsonResult = new JsonResult(new { message = "Unauthorized", redirectUrl = redirectUrl });
                context.Result = jsonResult;
            }
            else
            {
                context.Result = new RedirectResult(redirectUrl);
            }
        }

        public static Dictionary<string, string> GetTokenData(string tokenHeader)
        {
            var jwtHandler = new JwtSecurityTokenHandler();
            var jwtInput = tokenHeader;
            var readableToken = jwtHandler.CanReadToken(jwtInput);
            Dictionary<string, string> headerData = new Dictionary<string, string>();

            if (readableToken)
            {
                var token = jwtHandler.ReadJwtToken(jwtInput);
                var claims = token.Claims;
                IEnumerable<Claim> claimss = claims;
                foreach (Claim c in claims)
                {
                    if (c.Type == "role")
                    {
                        var count = headerData.Keys.Where(x => x.Contains("role")).ToList();
                        if (count.Count < 0)
                        {
                            headerData.Add(c.Type, c.Value);
                        }
                        else
                        {
                            //headerData.Add(c.Type, c.Value);
                        }
                    }
                    else
                        headerData.Add(c.Type, c.Value);
                }
            }
            return headerData;
        }
    }
}
