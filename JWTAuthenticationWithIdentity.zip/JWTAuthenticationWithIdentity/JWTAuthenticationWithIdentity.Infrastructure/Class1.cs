﻿using System;

namespace JWTAuthenticationWithIdentity.Infrastructure
{
    public class Class1
    {
    }
}
