﻿

using JWTAuthenticationWithIdentity.Services.Banks;
using JWTAuthenticationWithIdentity.Services.Customers;
using Microsoft.Extensions.DependencyInjection;

namespace JWTAuthenticationWithIdentity.Infrastructure
{
    public static class ServiceRegistration
    {
        public static void AddInfrastructure(this IServiceCollection services)
        {
            services.AddScoped<IBankService, BankService>();
            services.AddScoped<ICustomerService, CustomerService>();
        }
    }
}
