﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity.Core.Repositories.Genraics
{
    public class GenericRepository<T> : IGenericRepository<T>
         where T : class
    { 
        public GenericRepository()
        {
        }
        public Task<int> AddAsync(T entity)
        {
            throw new NotImplementedException();
        }

        public Task<T> AddWithResponseAsync(T entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<T, bool>> where)
        {
            throw new NotImplementedException();
        }

        public Task<TKey> DeleteAsync<TKey>(TKey id)
        {
            throw new NotImplementedException();
        }

        public bool Exists(Expression<Func<T, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public IQueryable<T> FindBy(Expression<Func<T, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public T Get(params object[] keyValues)
        {
            throw new NotImplementedException();
        }

        public IQueryable<T> GetAll(int page, int pageCount)
        {
            throw new NotImplementedException();
        }

        public IQueryable<T> GetAll(string include)
        {
            throw new NotImplementedException();
        }

        public IQueryable<T> GetAll(string include, string include2)
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<T>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public Task<T> GetByIdAsync<TKey>(TKey id)
        {
            throw new NotImplementedException();
        }

        public T GetFirst(Expression<Func<T, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public List<T> GetMany(Expression<Func<T, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public T GetSingle(Expression<Func<T, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public T HardDelete(T entity)
        {
            throw new NotImplementedException();
        }

        public IQueryable<T> RawSql(string sql, params object[] parameters)
        {
            throw new NotImplementedException();
        }

        public void SeEntityState(T entity)
        {
            throw new NotImplementedException();
        }

        public T SoftDelete(T entity)
        {
            throw new NotImplementedException();
        }

        public Task<TKey> UpdateAsync<TKey>(TKey entity)
        {
            throw new NotImplementedException();
        }

        public void UpdateRange(IEnumerable<T> entity)
        {
            throw new NotImplementedException();
        }
    }
}
