﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity.Core.Repositories.Genraics
{
    public interface IGenericRepository<T> where T : class
    {
        Task<IReadOnlyList<T>> GetAllAsync();
        Task<T> GetByIdAsync<TKey>(TKey id);
        Task<int> AddAsync(T entity);
        Task<T> AddWithResponseAsync(T entity);
        Task<TKey> UpdateAsync<TKey>(TKey entity);
        Task<TKey> DeleteAsync<TKey>(TKey id);


        //Task<IEnumerable<T>> GetAll();  
        //Task Update(int id, T company);
        //Task Delete(int id);

        T Get(params object[] keyValues);
        IQueryable<T> FindBy(Expression<Func<T, bool>> predicate);
        /// <returns>Queryable</returns>
        IQueryable<T> GetAll(int page, int pageCount);

        /// <returns>List of entities</returns>
        IQueryable<T> GetAll(string include);

        /// <returns>List of entities</returns>
        IQueryable<T> RawSql(string sql, params object[] parameters);

        /// <returns>List of entities</returns>
        IQueryable<T> GetAll(string include, string include2);
        /// <summary>
        /// Soft delete with using IsActive flag for entity
        /// </summary>
        /// <returns>The Entity's state</returns>
        T SoftDelete(T entity);

        /// <summary>
        /// Deletes the specified entity
        /// </summary>
        /// <returns>The Entity's state</returns>
        T HardDelete(T entity);
        bool Exists(Expression<Func<T, bool>> predicate);
        //void SaveLoginLogout(bool LogChange = false, string Description = "");

        /// <summary>
        /// Get First
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        T GetFirst(Expression<Func<T, bool>> predicate);
        List<T> GetMany(Expression<Func<T, bool>> predicate);
        T GetSingle(Expression<Func<T, bool>> predicate);
        void Delete(Expression<Func<T, bool>> where);
        void UpdateRange(IEnumerable<T> entity);
        void SeEntityState(T entity);
    }
}
