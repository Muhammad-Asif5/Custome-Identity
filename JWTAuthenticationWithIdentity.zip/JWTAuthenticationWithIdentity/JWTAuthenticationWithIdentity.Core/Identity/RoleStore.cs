﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using Dapper;
using JWTAuthenticationWithIdentity.Core.Context;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;

namespace JWTAuthenticationWithIdentity.Identity
{
    public class RoleStore : IRoleStore<ApplicationRole>,
        IQueryableRoleStore<ApplicationRole>,
        IRoleClaimStore<ApplicationRole>
    {
        private readonly string _connectionString;
        private readonly JWTAuthenticationWithIdentity.Core.ConnectionManager.IDbConnection _dbConnection;

        public IQueryable<ApplicationRole> Roles => null ??
            GetAllRoles().AsQueryable();

        public RoleStore(IConfiguration configuration, JWTAuthenticationWithIdentity.Core.ConnectionManager.IDbConnection dbConnection)
        {
            _connectionString = configuration.GetConnectionString("ConnStr");
            _dbConnection = dbConnection;
        }

        public IEnumerable<ApplicationRole> GetAllRoles()
        {
            IEnumerable<ApplicationRole> roles1 = null;
            using (var connection = _dbConnection.GetConnection)
            {
                var roles = connection.QueryAsync<ApplicationRole>($@"SELECT * FROM [Role]").Result;
                roles1 = roles;
            }
            return roles1;
        }

        //public async Task<IdentityResult> CreateAsync(ApplicationRole role, CancellationToken cancellationToken)
        //{
        //    cancellationToken.ThrowIfCancellationRequested();

        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        await connection.OpenAsync(cancellationToken);
        //         await connection.QuerySingleAsync<int>($@"INSERT INTO [Role] ([Id],[Name], [NormalizedName])
        //            VALUES (@{nameof(ApplicationRole.Id)},@{nameof(ApplicationRole.Name)}, @{nameof(ApplicationRole.NormalizedName)});
        //            SELECT CAST(SCOPE_IDENTITY() as int)", role);
        //    }

        //    return IdentityResult.Success;
        //}
        public virtual async Task<IdentityResult> CreateAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            using (var connection = new SqlConnection(_connectionString))
            {

                const string sql = "INSERT INTO [dbo].[Role] " +
                                   "VALUES (@Id, @Name, @NormalizedName, @ConcurrencyStamp);";
                var param = new DynamicParameters();
                param.Add("@Id", role.Id);
                param.Add("@Name", role.Name);
                param.Add("@NormalizedName", role.NormalizedName);
                param.Add("@ConcurrencyStamp", role.ConcurrencyStamp);

                var rowsInserted = await connection.ExecuteAsync(sql, param: param, commandType: CommandType.Text);
                return IdentityResult.Success;
            }

        }

        public async Task<IdentityResult> UpdateAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync(cancellationToken);
                await connection.ExecuteAsync($@"UPDATE [Role] SET
                    [Name] = @{nameof(ApplicationRole.Name)},
                    [NormalizedName] = @{nameof(ApplicationRole.NormalizedName)}
                    WHERE [Id] = @{nameof(ApplicationRole.Id)}", role);
            }

            return IdentityResult.Success;
        }

        public async Task<IdentityResult> DeleteAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync(cancellationToken);
                await connection.ExecuteAsync($"DELETE FROM [Role] WHERE [Id] = @{nameof(ApplicationRole.Id)}", role);
            }

            return IdentityResult.Success;
        }

        public Task<string> GetRoleIdAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            return Task.FromResult(role.Id.ToString());
        }

        public Task<string> GetRoleNameAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            return Task.FromResult(role.Name);
        }

        public Task SetRoleNameAsync(ApplicationRole role, string roleName, CancellationToken cancellationToken)
        {
            role.Name = roleName;
            return Task.FromResult(0);
        }

        public Task<string> GetNormalizedRoleNameAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            return Task.FromResult(role.NormalizedName);
        }

        public Task SetNormalizedRoleNameAsync(ApplicationRole role, string normalizedName, CancellationToken cancellationToken)
        {
            role.NormalizedName = normalizedName;
            return Task.FromResult(0);
        }

        public async Task<ApplicationRole> FindByIdAsync(string roleId, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync(cancellationToken);
                return await connection.QuerySingleOrDefaultAsync<ApplicationRole>($@"SELECT * FROM [Role]
                    WHERE [Id] = @{nameof(roleId)}", new { roleId });
            }
        }

        public async Task<ApplicationRole> FindByNameAsync(string normalizedRoleName, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            using (var connection = _dbConnection.GetConnection)
            {
                await connection.OpenAsync(cancellationToken);
                return await connection.QuerySingleOrDefaultAsync<ApplicationRole>($@"SELECT * FROM [Role]
                    WHERE [NormalizedName] = @{nameof(normalizedRoleName)}", new { normalizedRoleName });
            }
        }

        public void Dispose()
        {
            // Nothing to dispose.
        }

        public async Task<IList<Claim>> GetClaimsAsync(ApplicationRole role, CancellationToken cancellationToken = default)
        {
            IEnumerable<Claim> list = null;
            cancellationToken.ThrowIfCancellationRequested();
            using (var connection = _dbConnection.GetConnection)
            {
                await connection.OpenAsync(cancellationToken);
                const string sql = @"SELECT * FROM [dbo].[UserClaim] WHERE [UserId] = @UserId;";
                var userClaims = await connection.QueryAsync(sql, new { UserId = role.Id });
                if (userClaims.Count() > 0)
                {
                    return (IList<Claim>)userClaims.ToList();
                }
                else
                    return null;
                
            }
                
        }

        public Task AddClaimAsync(ApplicationRole role, Claim claim, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task RemoveClaimAsync(ApplicationRole role, Claim claim, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }
    }
}
