﻿using Dapper;
using JWTAuthenticationWithIdentity.Core.Repositories.Genraics;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity.Core.Uow
{
    public interface IUnitOfWork
    {
        Task<IReadOnlyList<TEntity>> GetAllAsync<TEntity>() where TEntity : class;
        IGenericRepository<TEntity> GetRepository<TEntity>() where TEntity : class;
        Task<IEnumerable<TEntity>> GetAllRepositoryBySpAsync<TEntity>(string spName, DynamicParameters parameters) where TEntity : class;
        Task<TEntity> GetSingleRepositoryBySp<TEntity>(string spName, DynamicParameters parameters) where TEntity : class;
        Task<TEntity> GetSingleRepositoryByQuery<TEntity>(string spName, DynamicParameters parameters) where TEntity : class;
        Task UpdateDeleteRepositoryBySpAsync(string spName, DynamicParameters parameters); 
        Task<TKey> AddRepositoryBySpAsync<TKey>(string spName, DynamicParameters parameters);

        SqlDataAdapter GetSpSqlDataAdapter(string spName);
        TEntity SpExecuteRepository<TEntity>(string spName, DynamicParameters parameters) where TEntity : class;
        List<TEntity> SpListRepositoryWithConnectionString<TEntity>(string connectionString, string query, DynamicParameters parameters) where TEntity : class;
        long getMaximumIdForPatientAndAppointment(string tableName, string columnName, string practiceCode);
        long getMaximumId(string columnName);
        void ExecuteCommand(string query, DynamicParameters parameters);

    }
}
