﻿using Dapper;
using JWTAuthenticationWithIdentity.Core.Repositories.Genraics;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity.Core.Uow
{
    public sealed class UnitOfWork : IUnitOfWork
    {
        private Dictionary<Type, object> _repos;
        private readonly JWTAuthenticationWithIdentity.Core.ConnectionManager.IDbConnection _context;
        public UnitOfWork( JWTAuthenticationWithIdentity.Core.ConnectionManager.IDbConnection context)
        {
            _context = context;
        }
        public IGenericRepository<TEntity> GetRepository<TEntity>() where TEntity : class
        {
            if (_repos == null)
            {
                _repos = new Dictionary<Type, object>();
            }

            var type = typeof(TEntity);
            if (!_repos.ContainsKey(type))
            {
                _repos[type] = new GenericRepository<TEntity>();
            }

            return (IGenericRepository<TEntity>)_repos[type];
        }
        public async Task<IEnumerable<TEntity>> GetAllRepositoryBySpAsync<TEntity>(string spName, DynamicParameters parameters) where TEntity : class
        {
            try
            {
                using (var sqlCon = _context.CreateConnection())
                {
                    var banks = await sqlCon.QueryAsync<TEntity>(spName, parameters, commandType: CommandType.StoredProcedure);
                    return banks.AsList();
                }
            }
            catch (Exception ex)
            {
                return new List<TEntity>();
            }
        }
        public async Task<TEntity> GetSingleRepositoryBySp<TEntity>(string spName, DynamicParameters parameters) where TEntity : class
        {
            try
            {
                using (var sqlCon = _context.CreateConnection())
                {
                    var bank = await sqlCon.QuerySingleOrDefaultAsync<TEntity>(spName, parameters, commandType: CommandType.StoredProcedure);
                    return bank;
                }
            }
            catch (Exception ex)
            {
                return null; ;
            }
        }
        public async Task<TKey> AddRepositoryBySpAsync<TKey>(string spName, DynamicParameters parameters)
        {
            try
            {
                using (var sqlCon = _context.CreateConnection())
                {
                    var bank = await sqlCon.QuerySingleAsync<TKey>(spName, parameters, commandType: CommandType.Text);
                    return bank;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public async Task UpdateDeleteRepositoryBySpAsync(string spName, DynamicParameters parameters)
        {
            try
            {
                using (var sqlCon = _context.CreateConnection())
                {
                    await sqlCon.ExecuteAsync(spName, parameters, commandType: CommandType.Text);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<TEntity> GetSingleRepositoryByQuery<TEntity>(string spName, DynamicParameters parameters) where TEntity : class
        {
            try
            {
                using (var sqlCon = _context.CreateConnection())
                {
                    var bank = await sqlCon.QuerySingleOrDefaultAsync<TEntity>(spName, parameters, commandType: CommandType.Text);
                    return bank;
                    // await sqlCon.ExecuteAsync(spName, parameters, commandType: CommandType.Text);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void ExecuteCommand(string spName, DynamicParameters parameters)
        {
            throw new NotImplementedException();
        }

        public long getMaximumId(string columnName)
        {
            throw new NotImplementedException();
        }
        public long getMaximumIdForPatientAndAppointment(string tableName, string columnName, string practiceCode)
        {
            throw new NotImplementedException();
        }
        public SqlDataAdapter GetSpSqlDataAdapter(string query)
        {
            throw new NotImplementedException();
        }
        public TEntity SpExecuteRepository<TEntity>(string spName, DynamicParameters parameters) where TEntity : class
        {
            throw new NotImplementedException();
        }
        public List<TEntity> SpListRepositoryWithConnectionString<TEntity>(string connectionString, string query, DynamicParameters parameters) where TEntity : class
        {
            throw new NotImplementedException();
        }
        public TEntity SpSingleRepositoryWithConnectionString<TEntity>(string query, DynamicParameters parameters) where TEntity : class
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<TEntity>> GetAllAsync<TEntity>() where TEntity : class
        {
            throw new NotImplementedException();
        }

      
    }
}
