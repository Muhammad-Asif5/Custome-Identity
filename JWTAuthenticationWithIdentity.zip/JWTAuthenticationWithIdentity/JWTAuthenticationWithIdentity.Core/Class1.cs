﻿using System;

namespace JWTAuthenticationWithIdentity.Core
{
    public class Class1
    {
    }
}
