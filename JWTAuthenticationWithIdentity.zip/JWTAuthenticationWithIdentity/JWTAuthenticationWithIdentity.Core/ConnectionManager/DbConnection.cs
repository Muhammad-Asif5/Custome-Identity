﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Linq;

namespace JWTAuthenticationWithIdentity.Core.ConnectionManager
{
    public interface IDbConnection
    {
        public SqlConnection GetConnection { get; }
        public SqlConnection CreateConnection();
        public SqlConnection GetConnectionStringServerBsed();
    }
    public class DbConnection : IDbConnection
    {
        private readonly string _connectionString;
        private readonly IConfiguration Configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public DbConnection(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            Configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
            _connectionString = Configuration.GetConnectionString("DefaultConnection");
        }
        public SqlConnection CreateConnection() => new SqlConnection(_connectionString);
        public SqlConnection GetConnection
        {
            get
            {
                //var connectionString = Configuration.GetConnectionString("DefaultConnection");
                return new SqlConnection(_connectionString);
            }
        }
        public SqlConnection GetConnectionStringServerBsed()
        {
            string serverId = getServerId();
            string connectionString = _connectionString;
            //switch (serverId)
            //{
            //    case "11":
            //        connectionString = m_config.GetConnectionString("ConnectionServer-11");
            //        break;
            //    case "14":
            //        connectionString = m_config.GetConnectionString("ConnectionServer-14");
            //        break;
            //    case "9":
            //        connectionString = m_config.GetConnectionString("ConnectionServer-9");
            //        break;
            //    default:
            //        break;
            //}
            return new SqlConnection(connectionString);
        }
        private string getServerId()
        {
            var serverId = "";
            if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated)
            {
                serverId = _httpContextAccessor.HttpContext.User.Identities.FirstOrDefault().Claims.FirstOrDefault(x => x.Type == "ServerId").Value;
            }
            return serverId;
        }
    }
}
