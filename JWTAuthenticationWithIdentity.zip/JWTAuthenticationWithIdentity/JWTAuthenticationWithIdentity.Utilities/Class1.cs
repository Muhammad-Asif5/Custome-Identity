﻿using System;

namespace JWTAuthenticationWithIdentity.Utilities
{
    public class Class1
    {
    }
}
