﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace JWTAuthenticationWithIdentity.Models.Customer
{
    [Table("Customers")]
    public class Customer
    {
        [Key]
        public int Cust_ID { get; set; }
        public string Lookup { get; set; }
        public string Cust_Code { get; set; }
        public string Company_Name { get; set; }
        public string Contact_Name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZIP_Code { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Fax { get; set; }
    }
}
