﻿using System;

namespace JWTAuthenticationWithIdentity.Models
{
    public class Class1
    {
    }
}
