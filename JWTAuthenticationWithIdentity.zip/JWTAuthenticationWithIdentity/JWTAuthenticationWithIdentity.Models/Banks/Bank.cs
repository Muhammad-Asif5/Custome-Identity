﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JWTAuthenticationWithIdentity.Models.Banks
{
    [Table("Bank")]
    public class Bank
    {
        [Key]
        public int Bank_ID { get; set; }
        public string Bank_Name { get; set; }
        public bool Status { get; set; }
    }
}
