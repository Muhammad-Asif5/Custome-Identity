﻿using System;

namespace JWTAuthenticationWithIdentity.Services
{
    public class Class1
    {
    }
}
