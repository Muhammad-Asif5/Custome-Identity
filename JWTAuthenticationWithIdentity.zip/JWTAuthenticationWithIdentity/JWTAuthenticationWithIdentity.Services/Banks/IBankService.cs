﻿using JWTAuthenticationWithIdentity.Core.Repositories.Genraics;
using JWTAuthenticationWithIdentity.Models.Banks;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity.Services.Banks
{
    public interface IBankService //: IGenericRepository<Bank>
    {
        public Task<IEnumerable<Bank>> GetAllBankAsync();
        public Task<Bank> GetBankByIdAsync(int id);
        public Task DeleteBankAsync(int id);
        public Task<Bank> CreateBankAsync(Bank company);
        public Task UpdateBankAsync(int id, Bank company);
    }
}
