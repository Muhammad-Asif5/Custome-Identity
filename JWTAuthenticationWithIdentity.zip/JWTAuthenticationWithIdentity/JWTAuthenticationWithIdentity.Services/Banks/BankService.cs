﻿using Dapper; 
using JWTAuthenticationWithIdentity.Core.Context;
using JWTAuthenticationWithIdentity.Core.Uow;
using JWTAuthenticationWithIdentity.Models.Banks;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity.Services.Banks
{   
    public class BankService : IBankService
    {
       
        private readonly IUnitOfWork unitOfWork;
        public BankService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<Bank>> GetAllBankAsync()
        {
            var spName = "spGetBanks";
            var parameters = new DynamicParameters();
            parameters.Add("@ID", dbType: DbType.Int32, value: 0, direction: ParameterDirection.Input);
            var bankList = await unitOfWork.GetAllRepositoryBySpAsync<Bank>(spName, parameters);
            if (bankList.Any())
            {
                return bankList;
            }
            return null;
        }
        public async Task<Bank> GetBankByIdAsync(int id)
        {
            var spName = "spGetBanks";
            var parameters = new DynamicParameters();
            parameters.Add("@ID", id, DbType.Int32, ParameterDirection.Input);
            var bank = await unitOfWork.GetSingleRepositoryBySp<Bank>(spName, parameters);
            return bank;
        }
        public async Task<Bank> CreateBankAsync(Bank company)
        {
            //var query2 = @"INSERT INTO Bank (Bank_ID,Bank_Name,Status) 
            //        OUTPUT INSERTED.Bank_ID, INSERTED.Bank_Name, INSERTED.Status
            //                        VALUES (@BankID, @BankName, @Status)";
            var spName = @"INSERT INTO Bank (Bank_ID,Bank_Name,Status) 
                                    OUTPUT INSERTED.Bank_ID 
                                    VALUES ((SELECT MAX(BANK_ID)+1 FROM BANK), @BankName, @Status) ";
            var parameters = new DynamicParameters();
            //parameters.Add("@BankID", company.Bank_ID, DbType.Int32);
            parameters.Add("@BankName", company.Bank_Name, DbType.String);
            parameters.Add("@Status", company.Status, DbType.String);

            try
            {
                var identity = await unitOfWork.AddRepositoryBySpAsync<int>(spName, parameters);
                var createdBank = new Bank
                {
                    Bank_ID = identity,
                    Bank_Name = company.Bank_Name,
                    Status = company.Status
                };
                return createdBank;
            }
            catch (System.Exception ex)
            {

                throw;
            }

        }
       
        public async Task UpdateBankAsync(int id, Bank company)
        {
            var spName = "UPDATE Bank SET Bank_Name = @Name, Status = @Status  WHERE Bank_ID = @Id";
            var parameters = new DynamicParameters();
            parameters.Add("Id", id, DbType.Int32);
            parameters.Add("Name", company.Bank_Name, DbType.String);
            parameters.Add("Status", company.Status, DbType.Boolean);
            ///await connection.ExecuteAsync(query, parameters);
            await unitOfWork.UpdateDeleteRepositoryBySpAsync(spName, parameters);
        }

        public async Task DeleteBankAsync(int id)
        {
            var parameters = new DynamicParameters();
            parameters.Add("Id", id, DbType.Int32);
            var spName = "DELETE FROM Bank WHERE Bank_ID = @Id";
            await unitOfWork.UpdateDeleteRepositoryBySpAsync(spName, parameters);
        }

    }
}
