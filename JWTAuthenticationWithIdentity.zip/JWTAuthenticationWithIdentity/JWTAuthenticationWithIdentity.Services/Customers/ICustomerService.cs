﻿using JWTAuthenticationWithIdentity.Models.Customer;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity.Services.Customers
{
    public interface ICustomerService
    {
        public Task<IEnumerable<Customer>> GetAllCustomerAsync();
        public Task<Customer> GetCustomerByIdAsync(int id);
        public Task DeleteCustomerAsync(int id);
        public Task<Customer> CreateCustomerAsync(Customer customer);
        public Task UpdateCustomerAsync(int id, Customer customer);
    }
}
