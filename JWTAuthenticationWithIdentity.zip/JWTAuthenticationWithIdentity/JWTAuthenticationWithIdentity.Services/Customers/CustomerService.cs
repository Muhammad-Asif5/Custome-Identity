﻿using Dapper;
using JWTAuthenticationWithIdentity.Core.Uow;
using JWTAuthenticationWithIdentity.Models.Customer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JWTAuthenticationWithIdentity.Services.Customers
{
    public class CustomerService : ICustomerService
    {
        private readonly IUnitOfWork unitOfWork;
        public CustomerService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }
        public Task<Customer> CreateCustomerAsync(Customer customer)
        {
            throw new NotImplementedException();
        }

        public Task DeleteCustomerAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Customer>> GetAllCustomerAsync()
        {
            var spName = "spGetCustomers";
            var parameters = new DynamicParameters();
            parameters.Add("@ID", dbType: DbType.Int32, value: 0, direction: ParameterDirection.Input);
            var bankList = await unitOfWork.GetAllRepositoryBySpAsync<Customer>(spName, parameters);
            if (bankList.Any())
            {
                return bankList;
            }
            return null;
        }

        public Task<Customer> GetCustomerByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task UpdateCustomerAsync(int id, Customer customer)
        {
            throw new NotImplementedException();
        }
    }
}
